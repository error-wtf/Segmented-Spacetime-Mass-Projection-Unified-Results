"""SSZ Projection Suite v1.0 - Anti-Capitalist Scientific Software"""
__version__ = "1.0"
